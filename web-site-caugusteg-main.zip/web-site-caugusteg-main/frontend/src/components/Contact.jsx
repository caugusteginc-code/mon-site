import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { Label } from './ui/label';
import { useToast } from '../hooks/use-toast';
import { 
  MapPin, 
  Phone, 
  Mail, 
  Clock, 
  Send,
  Loader2,
  MessageSquare,
  CheckCircle
} from 'lucide-react';
import axios from 'axios';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

// Helper functions
const formatPhone = (phone) => {
  const cleaned = phone.replace(/\D/g, '');
  if (cleaned.length === 10) {
    return `(${cleaned.slice(0,3)}) ${cleaned.slice(3,6)}-${cleaned.slice(6,10)}`;
  }
  return phone;
};

const validateEmail = (email) => {
  const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return regex.test(email);
};

const Contact = () => {
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    nom: '',
    email: '',
    telephone: '',
    message: ''
  });

  const handleInputChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handlePhoneChange = (value) => {
    const formatted = formatPhone(value);
    handleInputChange('telephone', formatted);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // Validation
    if (!formData.nom || !formData.email || !formData.message) {
      toast({
        title: "Champs requis manquants",
        description: "Veuillez remplir tous les champs obligatoires.",
        variant: "destructive"
      });
      return;
    }

    if (!validateEmail(formData.email)) {
      toast({
        title: "Email invalide",
        description: "Veuillez saisir une adresse email valide.",
        variant: "destructive"
      });
      return;
    }

    setIsSubmitting(true);

    try {
      // Appel API réel au backend
      const response = await axios.post(`${API}/contact`, formData);
      const result = response.data;
      
      if (result.success) {
        toast({
          title: "Message envoyé !",
          description: `${result.message} (Réf: ${result.ticketNumber})`,
        });

        // Reset form
        setFormData({
          nom: '',
          email: '',
          telephone: '',
          message: ''
        });
      }
    } catch (error) {
      console.error('Erreur lors de l\'envoi du message:', error);
      
      // Gestion des erreurs différenciées
      if (error.response && error.response.data) {
        const errorData = error.response.data;
        toast({
          title: "Erreur de validation",
          description: errorData.detail?.message || "Données invalides",
          variant: "destructive"
        });
      } else {
        toast({
          title: "Erreur de connexion",
          description: "Impossible de contacter le serveur. Vérifiez votre connexion.",
          variant: "destructive"
        });
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  const contactInfo = [
    {
      icon: MapPin,
      title: "Adresse",
      content: "3089 chemin de Chambly, app 7",
      subtitle: "Longueuil, QC J4L 1N3",
      action: "Voir sur la carte"
    },
    {
      icon: Phone,
      title: "Téléphone",
      content: "(438) 622-3020",
      subtitle: "Lun-Ven 8h-18h, Sam 9h-15h",
      action: "Appeler maintenant"
    },
    {
      icon: Mail,
      title: "Email",
      content: "caugusteginc@gmail.com",
      subtitle: "Réponse sous 24h",
      action: "Envoyer un email"
    }
  ];

  return (
    <section id="contact" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* En-tête */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            Contactez-<span className="text-blue-900">nous</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Une question ? Un projet ? N'hésitez pas à nous contacter. 
            Notre équipe est là pour vous accompagner dans vos défis informatiques.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* Informations de contact */}
          <div className="space-y-8">
            <div>
              <h3 className="text-2xl font-bold text-gray-900 mb-6">
                Nos coordonnées
              </h3>
              
              <div className="space-y-6">
                {contactInfo.map((info, index) => (
                  <Card key={index} className="hover:shadow-md transition-shadow duration-200">
                    <CardContent className="p-6">
                      <div className="flex items-start space-x-4">
                        <div className="bg-blue-100 rounded-lg p-3 flex-shrink-0">
                          <info.icon className="h-6 w-6 text-blue-900" />
                        </div>
                        
                        <div className="flex-1">
                          <h4 className="font-semibold text-gray-900 mb-1">
                            {info.title}
                          </h4>
                          <p className="text-lg text-blue-900 font-medium mb-1">
                            {info.content}
                          </p>
                          <p className="text-gray-600 text-sm mb-3">
                            {info.subtitle}
                          </p>
                          <button className="text-blue-900 text-sm font-medium hover:underline">
                            {info.action}
                          </button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>

            {/* Horaires */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Clock className="h-5 w-5 mr-2 text-blue-900" />
                  Heures d'ouverture
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Lundi - Vendredi</span>
                    <span className="font-medium text-gray-900">8h00 - 18h00</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Samedi</span>
                    <span className="font-medium text-gray-900">9h00 - 15h00</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Dimanche</span>
                    <span className="font-medium text-red-600">Fermé</span>
                  </div>
                  <div className="pt-2 border-t border-gray-200 mt-4">
                    <div className="flex items-center space-x-2 text-green-600">
                      <CheckCircle className="h-4 w-4" />
                      <span className="text-sm font-medium">Support d'urgence 24/7 disponible</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Formulaire de contact */}
          <Card className="sticky top-24">
            <CardHeader>
              <CardTitle className="text-2xl text-center text-blue-900 flex items-center justify-center">
                <MessageSquare className="h-6 w-6 mr-2" />
                Envoyez-nous un message
              </CardTitle>
              <p className="text-center text-gray-600">
                Décrivez votre projet ou votre problématique
              </p>
            </CardHeader>
            
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Nom */}
                <div>
                  <Label htmlFor="contact-nom">Nom complet *</Label>
                  <Input
                    id="contact-nom"
                    type="text"
                    value={formData.nom}
                    onChange={(e) => handleInputChange('nom', e.target.value)}
                    placeholder="Votre nom complet"
                    required
                  />
                </div>

                {/* Email */}
                <div>
                  <Label htmlFor="contact-email">Adresse email *</Label>
                  <Input
                    id="contact-email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => handleInputChange('email', e.target.value)}
                    placeholder="votre@email.com"
                    required
                  />
                </div>

                {/* Téléphone */}
                <div>
                  <Label htmlFor="contact-telephone">Téléphone</Label>
                  <Input
                    id="contact-telephone"
                    type="tel"
                    value={formData.telephone}
                    onChange={(e) => handlePhoneChange(e.target.value)}
                    placeholder="(514) 123-4567"
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    Optionnel - pour un retour plus rapide
                  </p>
                </div>

                {/* Message */}
                <div>
                  <Label htmlFor="contact-message">Votre message *</Label>
                  <Textarea
                    id="contact-message"
                    value={formData.message}
                    onChange={(e) => handleInputChange('message', e.target.value)}
                    placeholder="Décrivez votre demande, votre projet ou le problème que vous rencontrez..."
                    rows={6}
                    required
                  />
                </div>

                {/* Bouton submit */}
                <Button 
                  type="submit" 
                  size="lg"
                  disabled={isSubmitting}
                  className="w-full bg-blue-900 hover:bg-blue-800 text-white"
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Envoi en cours...
                    </>
                  ) : (
                    <>
                      <Send className="mr-2 h-4 w-4" />
                      Envoyer le message
                    </>
                  )}
                </Button>

                <div className="text-center">
                  <p className="text-xs text-gray-500">
                    * Champs obligatoires
                  </p>
                  <p className="text-xs text-green-600 mt-1">
                    🔒 Vos données sont protégées et ne seront jamais partagées
                  </p>
                </div>
              </form>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
};

export default Contact;