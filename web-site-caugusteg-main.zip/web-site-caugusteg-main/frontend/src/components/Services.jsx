import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { 
  Monitor, 
  Download, 
  Settings, 
  Shield, 
  Headphones,
  ArrowRight,
  CheckCircle,
  Users,
  Building
} from 'lucide-react';

const Services = () => {
  const services = [
    {
      icon: Headphones,
      title: "Soutien informatique",
      description: "Support technique complet pour particuliers et entreprises",
      features: [
        "Assistance téléphonique et en ligne",
        "Résolution de problèmes informatiques",
        "Conseil en équipement informatique",
        "Formation utilisateur"
      ],
      target: "Particuliers & Entreprises"
    },
    {
      icon: Download,
      title: "Installation et configuration",
      description: "Mise en place et paramétrage de vos logiciels",
      features: [
        "Installation de systèmes d'exploitation",
        "Configuration de logiciels professionnels",
        "Paramétrage de périphériques",
        "Migration de données"
      ],
      target: "Tous publics"
    },
    {
      icon: Settings,
      title: "Maintenance et optimisation",
      description: "Maintien des performances optimales de vos systèmes",
      features: [
        "Nettoyage et optimisation système",
        "Mise à jour sécurisée",
        "Diagnostic de performance",
        "Maintenance préventive"
      ],
      target: "Particuliers & PME"
    },
    {
      icon: Shield,
      title: "Cybersécurité",
      description: "Protection complète de vos données et systèmes",
      features: [
        "Audit de sécurité informatique",
        "Installation d'antivirus professionnel",
        "Sauvegarde et récupération",
        "Formation sensibilisation"
      ],
      target: "Entreprises"
    },
    {
      icon: Monitor,
      title: "Assistance technique",
      description: "Support à distance et interventions sur site",
      features: [
        "Dépannage à distance sécurisé",
        "Intervention sur site",
        "Maintenance préventive",
        "Support d'urgence"
      ],
      target: "Service 24/7"
    }
  ];

  const scrollToSection = (sectionId) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="services" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* En-tête de section */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            Nos <span className="text-blue-900">Services</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Des solutions informatiques complètes et personnalisées pour répondre 
            à tous vos besoins technologiques, du particulier à l'entreprise.
          </p>
        </div>

        {/* Grille des services */}
        <div className="grid lg:grid-cols-2 xl:grid-cols-3 gap-8 mb-16">
          {services.map((service, index) => (
            <Card key={index} className="hover:shadow-xl transition-all duration-300 transform hover:scale-105 bg-white">
              <CardHeader className="pb-4">
                <div className="flex items-start justify-between">
                  <div className="bg-blue-100 rounded-lg p-3 mb-4">
                    <service.icon className="h-8 w-8 text-blue-900" />
                  </div>
                  <span className="bg-gray-100 text-gray-700 text-xs font-medium px-2 py-1 rounded-full">
                    {service.target}
                  </span>
                </div>
                <CardTitle className="text-xl text-gray-900">
                  {service.title}
                </CardTitle>
                <p className="text-gray-600">{service.description}</p>
              </CardHeader>
              
              <CardContent className="pt-0">
                <ul className="space-y-2 mb-6">
                  {service.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-center space-x-2">
                      <CheckCircle className="h-4 w-4 text-green-600 flex-shrink-0" />
                      <span className="text-sm text-gray-600">{feature}</span>
                    </li>
                  ))}
                </ul>
                
                <Button 
                  variant="outline" 
                  className="w-full border-blue-900 text-blue-900 hover:bg-blue-900 hover:text-white transition-colors duration-200"
                  onClick={() => scrollToSection('contact')}
                >
                  En savoir plus
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Section call-to-action */}
        <div className="bg-blue-900 rounded-2xl p-8 md:p-12 text-center">
          <h3 className="text-2xl md:text-3xl font-bold text-white mb-4">
            Besoin d'un service personnalisé ?
          </h3>
          <p className="text-blue-100 text-lg mb-8 max-w-2xl mx-auto">
            Chaque client est unique. Nous analysons vos besoins spécifiques 
            pour vous proposer la solution informatique la plus adaptée.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              size="lg"
              className="bg-white text-blue-900 hover:bg-gray-100 transition-colors duration-200"
              onClick={() => scrollToSection('tarifs')}
            >
              <Users className="mr-2 h-5 w-5" />
              Demander un devis
            </Button>
            <Button 
              variant="outline" 
              size="lg"
              className="border-white text-white hover:bg-white hover:text-blue-900 transition-colors duration-200"
              onClick={() => scrollToSection('contact')}
            >
              <Building className="mr-2 h-5 w-5" />
              Consultation gratuite
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Services;