import React from 'react';
import { Card, CardContent } from './ui/card';
import { Shield, Users, Clock, CheckCircle } from 'lucide-react';

const About = () => {
  const values = [
    {
      icon: Shield,
      title: "Fiabilité",
      description: "Des solutions informatiques robustes et sécurisées pour votre tranquillité d'esprit."
    },
    {
      icon: Users,
      title: "Professionnalisme",
      description: "Une équipe d'experts qualifiés avec des années d'expérience dans le domaine."
    },
    {
      icon: Clock,
      title: "Proximité",
      description: "Un service personnalisé et une présence locale pour mieux vous accompagner."
    }
  ];

  const achievements = [
    { number: "500+", label: "Clients satisfaits" },
    { number: "10+", label: "Années d'expérience" },
    { number: "24/7", label: "Support disponible" },
    { number: "100%", label: "Satisfaction client" }
  ];

  return (
    <section id="apropos" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* En-tête de section */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            À propos de <span className="text-blue-900">CAUGUSTEG Inc.</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Depuis notre création, nous nous engageons à fournir des services informatiques 
            de haute qualité, adaptés aux besoins spécifiques de chaque client.
          </p>
        </div>

        {/* Histoire et mission */}
        <div className="grid lg:grid-cols-2 gap-12 items-center mb-20">
          <div>
            <h3 className="text-2xl font-bold text-gray-900 mb-6">Notre histoire</h3>
            <p className="text-gray-600 mb-6 leading-relaxed">
              CAUGUSTEG Inc. a été fondée avec une vision claire : démocratiser l'accès 
              aux technologies informatiques pour tous, particuliers comme entreprises. 
              Basée à Longueuil, notre entreprise s'est développée grâce à notre approche 
              centrée sur le client et notre expertise technique reconnue.
            </p>
            <p className="text-gray-600 mb-6 leading-relaxed">
              Aujourd'hui, nous sommes fiers d'accompagner nos clients dans leur 
              transformation digitale, en offrant des solutions sur mesure qui 
              répondent à leurs défis technologiques.
            </p>
            
            <div className="flex items-center space-x-2 text-blue-900">
              <CheckCircle className="h-5 w-5" />
              <span className="font-semibold">Entreprise certifiée et assurée</span>
            </div>
          </div>

          <div className="relative">
            <Card className="transform rotate-1 shadow-xl">
              <CardContent className="p-8">
                <h4 className="text-xl font-bold text-blue-900 mb-4">Notre mission</h4>
                <p className="text-gray-600 mb-6">
                  "Fournir des solutions informatiques innovantes et fiables, 
                  en maintenant une relation de confiance et de proximité avec nos clients."
                </p>
                <div className="bg-blue-50 p-4 rounded-lg">
                  <p className="text-blue-900 font-semibold text-center">
                    Votre réussite technologique est notre priorité
                  </p>
                </div>
              </CardContent>
            </Card>
            
            {/* Éléments décoratifs */}
            <div className="absolute -top-3 -left-3 bg-blue-900 rounded-full w-6 h-6"></div>
            <div className="absolute -bottom-3 -right-3 bg-yellow-400 rounded-full w-4 h-4"></div>
          </div>
        </div>

        {/* Nos valeurs */}
        <div className="mb-16">
          <h3 className="text-2xl font-bold text-center text-gray-900 mb-12">Nos valeurs</h3>
          <div className="grid md:grid-cols-3 gap-8">
            {values.map((value, index) => (
              <Card key={index} className="text-center hover:shadow-lg transition-all duration-200 transform hover:scale-105">
                <CardContent className="p-8">
                  <div className="bg-blue-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-6">
                    <value.icon className="h-8 w-8 text-blue-900" />
                  </div>
                  <h4 className="text-xl font-bold text-gray-900 mb-4">{value.title}</h4>
                  <p className="text-gray-600">{value.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Chiffres clés */}
        <div className="bg-gradient-to-r from-blue-900 to-blue-800 rounded-2xl p-8 md:p-12">
          <h3 className="text-2xl font-bold text-center text-white mb-12">
            Ils nous font confiance
          </h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {achievements.map((achievement, index) => (
              <div key={index} className="text-center">
                <div className="text-3xl md:text-4xl font-bold text-white mb-2">
                  {achievement.number}
                </div>
                <div className="text-blue-100 font-medium">
                  {achievement.label}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;