import React from 'react';
import { Button } from './ui/button';
import { ArrowRight, Shield, Settings, Users } from 'lucide-react';

const Hero = () => {
  const scrollToSection = (sectionId) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="accueil" className="bg-gradient-to-br from-blue-50 to-white py-20 lg:py-32">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="lg:grid lg:grid-cols-12 lg:gap-12 items-center">
          {/* Contenu principal */}
          <div className="lg:col-span-7">
            <div className="mb-8">
              <div className="inline-flex items-center bg-blue-100 text-blue-800 text-sm font-medium px-4 py-2 rounded-full mb-6">
                <Shield className="h-4 w-4 mr-2" />
                Services informatiques de confiance
              </div>
              
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-gray-900 leading-tight mb-6">
                Votre partenaire <span className="text-blue-900">informatique</span> de confiance
              </h1>
              
              <p className="text-xl text-gray-600 mb-8 leading-relaxed">
                CAUGUSTEG Inc. vous accompagne dans tous vos besoins informatiques. 
                De la maintenance à la cybersécurité, nous offrons des solutions 
                professionnelles adaptées aux particuliers et aux entreprises.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-4 mb-12">
              <Button 
                size="lg"
                onClick={() => scrollToSection('tarifs')}
                className="bg-blue-900 hover:bg-blue-800 text-white px-8 py-4 text-lg font-semibold transition-all duration-200 transform hover:scale-105"
              >
                Demander un devis
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
              
              <Button 
                variant="outline" 
                size="lg"
                onClick={() => scrollToSection('contact')}
                className="border-blue-900 text-blue-900 hover:bg-blue-900 hover:text-white px-8 py-4 text-lg font-semibold transition-all duration-200"
              >
                Nous contacter
              </Button>
            </div>

            {/* Points clés */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="flex items-center space-x-3">
                <div className="bg-green-100 p-2 rounded-full">
                  <Settings className="h-5 w-5 text-green-600" />
                </div>
                <span className="text-gray-700 font-medium">Support technique expert</span>
              </div>
              <div className="flex items-center space-x-3">
                <div className="bg-blue-100 p-2 rounded-full">
                  <Shield className="h-5 w-5 text-blue-600" />
                </div>
                <span className="text-gray-700 font-medium">Sécurité garantie</span>
              </div>
              <div className="flex items-center space-x-3">
                <div className="bg-purple-100 p-2 rounded-full">
                  <Users className="h-5 w-5 text-purple-600" />
                </div>
                <span className="text-gray-700 font-medium">Service personnalisé</span>
              </div>
            </div>
          </div>

          {/* Image/Illustration côté droit */}
          <div className="lg:col-span-5 mt-12 lg:mt-0">
            <div className="relative">
              <div className="bg-blue-900 rounded-2xl p-8 text-white transform rotate-3 shadow-2xl">
                <div className="grid grid-cols-2 gap-4 mb-6">
                  <div className="bg-blue-800 rounded-lg p-4 text-center">
                    <Settings className="h-8 w-8 mx-auto mb-2" />
                    <p className="text-sm font-semibold">Maintenance</p>
                  </div>
                  <div className="bg-blue-800 rounded-lg p-4 text-center">
                    <Shield className="h-8 w-8 mx-auto mb-2" />
                    <p className="text-sm font-semibold">Sécurité</p>
                  </div>
                  <div className="bg-blue-800 rounded-lg p-4 text-center">
                    <Users className="h-8 w-8 mx-auto mb-2" />
                    <p className="text-sm font-semibold">Support</p>
                  </div>
                  <div className="bg-blue-800 rounded-lg p-4 text-center">
                    <ArrowRight className="h-8 w-8 mx-auto mb-2" />
                    <p className="text-sm font-semibold">Solutions</p>
                  </div>
                </div>
                <p className="text-center font-semibold">Services informatiques complets</p>
              </div>
              
              {/* Éléments décoratifs */}
              <div className="absolute -top-4 -left-4 bg-yellow-400 rounded-full w-8 h-8 animate-pulse"></div>
              <div className="absolute -bottom-4 -right-4 bg-green-400 rounded-full w-6 h-6 animate-pulse"></div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;