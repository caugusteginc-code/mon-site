import React from 'react';
import { Card } from './ui/card';
import { 
  Monitor, 
  Facebook, 
  Linkedin, 
  Mail, 
  Phone, 
  MapPin,
  ArrowUp,
  Shield,
  Clock,
  Award
} from 'lucide-react';

const Footer = () => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const scrollToSection = (sectionId) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const currentYear = new Date().getFullYear();

  const quickLinks = [
    { name: 'Accueil', id: 'accueil' },
    { name: 'À propos', id: 'apropos' },
    { name: 'Services', id: 'services' },
    { name: 'Tarifs', id: 'tarifs' },
    { name: 'Contact', id: 'contact' }
  ];

  const services = [
    'Soutien informatique',
    'Installation & configuration',
    'Maintenance système',
    'Cybersécurité',
    'Assistance technique'
  ];

  const certifications = [
    { icon: Shield, text: 'Certifié sécurité' },
    { icon: Award, text: 'Service de qualité' },
    { icon: Clock, text: 'Support 24/7' }
  ];

  return (
    <footer className="bg-gray-900 text-white">
      {/* Section principale */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid lg:grid-cols-4 md:grid-cols-2 gap-8">
          {/* Logo et description */}
          <div className="lg:col-span-1">
            <div className="flex items-center space-x-3 mb-6">
              <img 
                src="https://customer-assets.emergentagent.com/job_sitecraft-12/artifacts/avr5dz76_Logo%20de%20CAUGUSTEG%20Inc..png"
                alt="CAUGUSTEG Inc. Logo"
                className="h-12 w-12 object-contain"
              />
              <div>
                <h3 className="text-2xl font-bold text-white">CAUGUSTEG Inc.</h3>
                <p className="text-gray-400 text-sm">Services Informatiques</p>
              </div>
            </div>
            
            <p className="text-gray-300 mb-6 leading-relaxed">
              Votre partenaire informatique de confiance à Longueuil. 
              Solutions professionnelles pour particuliers et entreprises.
            </p>

            {/* Certifications */}
            <div className="space-y-2">
              {certifications.map((cert, index) => (
                <div key={index} className="flex items-center space-x-2 text-sm text-gray-400">
                  <cert.icon className="h-4 w-4 text-blue-400" />
                  <span>{cert.text}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Navigation rapide */}
          <div>
            <h4 className="text-lg font-semibold text-white mb-6">Navigation</h4>
            <ul className="space-y-3">
              {quickLinks.map((link, index) => (
                <li key={index}>
                  <button
                    onClick={() => scrollToSection(link.id)}
                    className="text-gray-300 hover:text-white transition-colors duration-200 text-left"
                  >
                    {link.name}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Services */}
          <div>
            <h4 className="text-lg font-semibold text-white mb-6">Nos services</h4>
            <ul className="space-y-3">
              {services.map((service, index) => (
                <li key={index} className="text-gray-300 text-sm">
                  {service}
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-lg font-semibold text-white mb-6">Contact</h4>
            <div className="space-y-4">
              <div className="flex items-start space-x-3">
                <MapPin className="h-5 w-5 text-blue-400 mt-0.5 flex-shrink-0" />
                <div className="text-sm text-gray-300">
                  <p>3089 chemin de Chambly, app 7</p>
                  <p>Longueuil, QC J4L 1N3</p>
                </div>
              </div>
              
              <div className="flex items-center space-x-3">
                <Phone className="h-5 w-5 text-blue-400 flex-shrink-0" />
                <a 
                  href="tel:(438)622-3020" 
                  className="text-sm text-gray-300 hover:text-white transition-colors duration-200"
                >
                  (438) 622-3020
                </a>
              </div>
              
              <div className="flex items-center space-x-3">
                <Mail className="h-5 w-5 text-blue-400 flex-shrink-0" />
                <a 
                  href="mailto:caugusteginc@gmail.com" 
                  className="text-sm text-gray-300 hover:text-white transition-colors duration-200"
                >
                  caugusteginc@gmail.com
                </a>
              </div>
            </div>

            {/* Réseaux sociaux */}
            <div className="mt-6">
              <h5 className="text-white font-medium mb-3">Suivez-nous</h5>
              <div className="flex space-x-3">
                <a 
                  href="#" 
                  className="bg-gray-800 p-2 rounded-lg hover:bg-blue-600 transition-colors duration-200"
                  aria-label="Facebook"
                >
                  <Facebook className="h-5 w-5" />
                </a>
                <a 
                  href="#" 
                  className="bg-gray-800 p-2 rounded-lg hover:bg-blue-600 transition-colors duration-200"
                  aria-label="LinkedIn"
                >
                  <Linkedin className="h-5 w-5" />
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Section copyright */}
      <div className="border-t border-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="md:flex md:items-center md:justify-between">
            <div className="text-sm text-gray-400">
              <p>© {currentYear} CAUGUSTEG Inc. Tous droits réservés.</p>
              <p className="mt-1">
                <button className="hover:text-white transition-colors duration-200">
                  Mentions légales
                </button>
                <span className="mx-2">•</span>
                <button className="hover:text-white transition-colors duration-200">
                  Politique de confidentialité
                </button>
                <span className="mx-2">•</span>
                <button className="hover:text-white transition-colors duration-200">
                  Conditions d'utilisation
                </button>
              </p>
            </div>
            
            <div className="mt-4 md:mt-0">
              <button
                onClick={scrollToTop}
                className="inline-flex items-center space-x-2 bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded-lg transition-colors duration-200"
              >
                <ArrowUp className="h-4 w-4" />
                <span className="text-sm font-medium">Haut de page</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Badge de confiance */}
      <div className="bg-gray-800 border-t border-gray-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="text-center">
            <p className="text-xs text-gray-500">
              🔒 Site sécurisé • 🇨🇦 Entreprise québécoise • ⭐ Service de qualité certifié
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;