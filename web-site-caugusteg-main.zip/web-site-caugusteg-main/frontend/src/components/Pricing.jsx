import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Label } from './ui/label';
import { useToast } from '../hooks/use-toast';
import { 
  Calculator, 
  Send, 
  CheckCircle, 
  Clock, 
  User, 
  Building,
  Loader2
} from 'lucide-react';
import axios from 'axios';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

// Data constants (remplaçant mock.js)
const clientTypes = [
  { id: 'particulier', name: 'Particulier', description: 'Personne physique' },
  { id: 'petite-entreprise', name: 'Petite entreprise (1-10 employés)', description: 'PME' },
  { id: 'moyenne-entreprise', name: 'Moyenne entreprise (11-50 employés)', description: 'PME' },
  { id: 'grande-entreprise', name: 'Grande entreprise (50+ employés)', description: 'Entreprise' }
];

const services = [
  { id: 'support', name: 'Soutien informatique', category: 'Support' },
  { id: 'installation', name: 'Installation et configuration', category: 'Installation' },
  { id: 'maintenance', name: 'Maintenance et optimisation', category: 'Maintenance' },
  { id: 'cybersecurity', name: 'Cybersécurité', category: 'Sécurité' },
  { id: 'assistance', name: 'Assistance technique', category: 'Support' },
  { id: 'autre', name: 'Autre service', category: 'Personnalisé' }
];

const priorities = [
  { id: 'low', name: 'Faible - Dans la semaine', color: 'green' },
  { id: 'normal', name: 'Normal - Dans 2-3 jours', color: 'blue' },
  { id: 'high', name: 'Urgent - Dans 24h', color: 'orange' },
  { id: 'critical', name: 'Critique - Immédiat', color: 'red' }
];

// Helper functions
const formatPhone = (phone) => {
  const cleaned = phone.replace(/\D/g, '');
  if (cleaned.length === 10) {
    return `(${cleaned.slice(0,3)}) ${cleaned.slice(3,6)}-${cleaned.slice(6,10)}`;
  }
  return phone;
};

const validateEmail = (email) => {
  const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return regex.test(email);
};

const Pricing = () => {
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    nom: '',
    email: '',
    telephone: '',
    entreprise: '',
    typeClient: '',
    services: [],
    description: '',
    priorite: 'normal'
  });

  const handleInputChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleServiceChange = (serviceId, checked) => {
    setFormData(prev => ({
      ...prev,
      services: checked 
        ? [...prev.services, serviceId]
        : prev.services.filter(s => s !== serviceId)
    }));
  };

  const handlePhoneChange = (value) => {
    const formatted = formatPhone(value);
    handleInputChange('telephone', formatted);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // Validation
    if (!formData.nom || !formData.email || !formData.telephone) {
      toast({
        title: "Champs requis manquants",
        description: "Veuillez remplir tous les champs obligatoires.",
        variant: "destructive"
      });
      return;
    }

    if (!validateEmail(formData.email)) {
      toast({
        title: "Email invalide",
        description: "Veuillez saisir une adresse email valide.",
        variant: "destructive"
      });
      return;
    }

    if (formData.services.length === 0) {
      toast({
        title: "Service requis",
        description: "Veuillez sélectionner au moins un service.",
        variant: "destructive"
      });
      return;
    }

    setIsSubmitting(true);

    try {
      // Appel API réel au backend
      const response = await axios.post(`${API}/quote`, formData);
      const result = response.data;
      
      if (result.success) {
        toast({
          title: "Devis envoyé !",
          description: `${result.message} (Réf: ${result.referenceNumber})`,
        });

        // Reset form
        setFormData({
          nom: '',
          email: '',
          telephone: '',
          entreprise: '',
          typeClient: '',
          services: [],
          description: '',
          priorite: 'normal'
        });
      }
    } catch (error) {
      console.error('Erreur lors de l\'envoi du devis:', error);
      
      // Gestion des erreurs différenciées
      if (error.response && error.response.data) {
        const errorData = error.response.data;
        toast({
          title: "Erreur de validation",
          description: errorData.detail?.message || "Données invalides",
          variant: "destructive"
        });
      } else {
        toast({
          title: "Erreur de connexion",
          description: "Impossible de contacter le serveur. Vérifiez votre connexion.",
          variant: "destructive"
        });
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <section id="tarifs" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* En-tête */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            Tarifs & <span className="text-blue-900">Devis</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Obtenez un devis personnalisé adapté à vos besoins spécifiques. 
            Nos tarifs sont transparents et compétitifs.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-start">
          {/* Informations tarifs */}
          <div>
            <Card className="mb-8">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Calculator className="h-6 w-6 mr-2 text-blue-900" />
                  Notre approche tarifaire
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="flex items-start space-x-3">
                    <CheckCircle className="h-5 w-5 text-green-600 mt-0.5 flex-shrink-0" />
                    <div>
                      <h4 className="font-semibold text-gray-900">Devis gratuit et sans engagement</h4>
                      <p className="text-gray-600">Évaluation complète de vos besoins</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start space-x-3">
                    <Clock className="h-5 w-5 text-blue-600 mt-0.5 flex-shrink-0" />
                    <div>
                      <h4 className="font-semibold text-gray-900">Tarification transparente</h4>
                      <p className="text-gray-600">Pas de frais cachés, prix fixés à l'avance</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start space-x-3">
                    <User className="h-5 w-5 text-purple-600 mt-0.5 flex-shrink-0" />
                    <div>
                      <h4 className="font-semibold text-gray-900">Adaptation à votre budget</h4>
                      <p className="text-gray-600">Solutions flexibles pour tous les budgets</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Gammes de tarifs */}
            <div className="space-y-4">
              <h3 className="text-xl font-bold text-gray-900 mb-4">Exemples de tarifs</h3>
              
              <div className="bg-gray-50 rounded-lg p-4">
                <div className="flex justify-between items-center">
                  <span className="font-medium text-gray-900">Support téléphonique</span>
                  <span className="text-blue-900 font-semibold">À partir de 50$/h</span>
                </div>
              </div>
              
              <div className="bg-gray-50 rounded-lg p-4">
                <div className="flex justify-between items-center">
                  <span className="font-medium text-gray-900">Intervention sur site</span>
                  <span className="text-blue-900 font-semibold">À partir de 80$/h</span>
                </div>
              </div>
              
              <div className="bg-gray-50 rounded-lg p-4">
                <div className="flex justify-between items-center">
                  <span className="font-medium text-gray-900">Maintenance mensuelle</span>
                  <span className="text-blue-900 font-semibold">Forfait sur mesure</span>
                </div>
              </div>
              
              <p className="text-sm text-gray-500 mt-4">
                * Tarifs indicatifs. Le prix final dépend de la complexité et de la durée d'intervention.
              </p>
            </div>
          </div>

          {/* Formulaire de devis */}
          <Card className="sticky top-24">
            <CardHeader>
              <CardTitle className="text-2xl text-center text-blue-900">
                Demander un devis personnalisé
              </CardTitle>
              <p className="text-center text-gray-600">
                Remplissez ce formulaire pour recevoir votre devis gratuit
              </p>
            </CardHeader>
            
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Informations personnelles */}
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="nom">Nom complet *</Label>
                    <Input
                      id="nom"
                      type="text"
                      value={formData.nom}
                      onChange={(e) => handleInputChange('nom', e.target.value)}
                      placeholder="Votre nom complet"
                      required
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="email">Email *</Label>
                    <Input
                      id="email"
                      type="email"
                      value={formData.email}
                      onChange={(e) => handleInputChange('email', e.target.value)}
                      placeholder="votre@email.com"
                      required
                    />
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="telephone">Téléphone *</Label>
                    <Input
                      id="telephone"
                      type="tel"
                      value={formData.telephone}
                      onChange={(e) => handlePhoneChange(e.target.value)}
                      placeholder="(514) 123-4567"
                      required
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="entreprise">Entreprise</Label>
                    <Input
                      id="entreprise"
                      type="text"
                      value={formData.entreprise}
                      onChange={(e) => handleInputChange('entreprise', e.target.value)}
                      placeholder="Nom de votre entreprise"
                    />
                  </div>
                </div>

                {/* Type de client */}
                <div>
                  <Label htmlFor="typeClient">Type de client</Label>
                  <Select value={formData.typeClient} onValueChange={(value) => handleInputChange('typeClient', value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Sélectionnez votre profil" />
                    </SelectTrigger>
                    <SelectContent>
                      {clientTypes.map(type => (
                        <SelectItem key={type.id} value={type.id}>
                          <div className="flex items-center">
                            {type.id === 'particulier' ? <User className="h-4 w-4 mr-2" /> : <Building className="h-4 w-4 mr-2" />}
                            {type.name}
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Services */}
                <div>
                  <Label>Services souhaités *</Label>
                  <div className="grid grid-cols-1 gap-3 mt-2">
                    {services.map(service => (
                      <label key={service.id} className="flex items-center space-x-2 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={formData.services.includes(service.id)}
                          onChange={(e) => handleServiceChange(service.id, e.target.checked)}
                          className="rounded border-gray-300"
                        />
                        <span className="text-sm">{service.name}</span>
                      </label>
                    ))}
                  </div>
                </div>

                {/* Priorité */}
                <div>
                  <Label htmlFor="priorite">Urgence</Label>
                  <Select value={formData.priorite} onValueChange={(value) => handleInputChange('priorite', value)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {priorities.map(priority => (
                        <SelectItem key={priority.id} value={priority.id}>
                          <span className={`inline-block w-2 h-2 rounded-full mr-2 bg-${priority.color}-500`}></span>
                          {priority.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Description */}
                <div>
                  <Label htmlFor="description">Description détaillée</Label>
                  <Textarea
                    id="description"
                    value={formData.description}
                    onChange={(e) => handleInputChange('description', e.target.value)}
                    placeholder="Décrivez vos besoins en détail..."
                    rows={4}
                  />
                </div>

                {/* Bouton submit */}
                <Button 
                  type="submit" 
                  size="lg"
                  disabled={isSubmitting}
                  className="w-full bg-blue-900 hover:bg-blue-800 text-white"
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Envoi en cours...
                    </>
                  ) : (
                    <>
                      <Send className="mr-2 h-4 w-4" />
                      Envoyer ma demande de devis
                    </>
                  )}
                </Button>

                <p className="text-xs text-gray-500 text-center">
                  * Champs obligatoires. Réponse garantie sous 24h.
                </p>
              </form>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
};

export default Pricing;