// Mock data pour les formulaires et interactions
export const mockData = {
  // Simulation envoi formulaire de devis
  submitQuoteForm: async (formData) => {
    console.log('🔧 Mock - Demande de devis envoyée:', formData);
    
    // Simuler un délai d'envoi
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    return {
      success: true,
      message: 'Votre demande de devis a été envoyée avec succès ! Nous vous contacterons dans les 24h.',
      referenceNumber: 'DEV-' + Math.random().toString(36).substr(2, 9).toUpperCase()
    };
  },

  // Simulation envoi formulaire de contact
  submitContactForm: async (formData) => {
    console.log('📞 Mock - Message de contact envoyé:', formData);
    
    // Simuler un délai d'envoi
    await new Promise(resolve => setTimeout(resolve, 1200));
    
    return {
      success: true,
      message: 'Votre message a été envoyé avec succès ! Nous vous répondrons rapidement.',
      ticketNumber: 'MSG-' + Math.random().toString(36).substr(2, 9).toUpperCase()
    };
  },

  // Services détaillés pour les formulaires
  services: [
    { id: 'support', name: 'Soutien informatique', category: 'Support' },
    { id: 'installation', name: 'Installation et configuration', category: 'Installation' },
    { id: 'maintenance', name: 'Maintenance et optimisation', category: 'Maintenance' },
    { id: 'cybersecurity', name: 'Cybersécurité', category: 'Sécurité' },
    { id: 'assistance', name: 'Assistance technique', category: 'Support' },
    { id: 'autre', name: 'Autre service', category: 'Personnalisé' }
  ],

  // Types de clients
  clientTypes: [
    { id: 'particulier', name: 'Particulier', description: 'Personne physique' },
    { id: 'petite-entreprise', name: 'Petite entreprise (1-10 employés)', description: 'PME' },
    { id: 'moyenne-entreprise', name: 'Moyenne entreprise (11-50 employés)', description: 'PME' },
    { id: 'grande-entreprise', name: 'Grande entreprise (50+ employés)', description: 'Entreprise' }
  ],

  // Urgence/priorité
  priorities: [
    { id: 'low', name: 'Faible - Dans la semaine', color: 'green' },
    { id: 'normal', name: 'Normal - Dans 2-3 jours', color: 'blue' },
    { id: 'high', name: 'Urgent - Dans 24h', color: 'orange' },
    { id: 'critical', name: 'Critique - Immédiat', color: 'red' }
  ]
};

// Helpers pour les validations
export const validators = {
  email: (email) => {
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return regex.test(email);
  },
  
  phone: (phone) => {
    // Format canadien (xxx) xxx-xxxx
    const regex = /^\(\d{3}\)\s\d{3}-\d{4}$/;
    return regex.test(phone);
  },
  
  formatPhone: (phone) => {
    // Nettoie et formate le numéro de téléphone
    const cleaned = phone.replace(/\D/g, '');
    if (cleaned.length === 10) {
      return `(${cleaned.slice(0,3)}) ${cleaned.slice(3,6)}-${cleaned.slice(6,10)}`;
    }
    return phone;
  }
};

export default mockData;