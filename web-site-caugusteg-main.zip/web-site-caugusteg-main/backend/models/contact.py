from pydantic import BaseModel, Field, EmailStr, validator
from typing import Optional, List
from datetime import datetime
from enum import Enum
import uuid
import re


class ContactStatus(str, Enum):
    nouveau = "nouveau"
    en_cours = "en_cours"
    traite = "traite"


class ContactMessageCreate(BaseModel):
    nom: str = Field(..., min_length=2, max_length=100, description="Nom complet")
    email: EmailStr = Field(..., description="Adresse email valide")
    telephone: Optional[str] = Field(None, description="Numéro de téléphone")
    message: str = Field(..., min_length=10, max_length=2000, description="Message")
    
    @validator('nom')
    def validate_nom(cls, v):
        if not v.strip():
            raise ValueError('Le nom ne peut pas être vide')
        # Vérifier que le nom contient au moins des caractères alphabétiques
        if not re.search(r'[a-zA-ZÀ-ÿ]', v):
            raise ValueError('Le nom doit contenir des lettres')
        return v.strip()
    
    @validator('telephone')
    def validate_telephone(cls, v):
        if v is None:
            return v
        # Nettoyer le téléphone (enlever espaces, parenthèses, tirets)
        cleaned = re.sub(r'[^\d]', '', v)
        # Vérifier format canadien (10 chiffres)
        if len(cleaned) != 10:
            raise ValueError('Le numéro de téléphone doit contenir 10 chiffres')
        # Formatter au format (XXX) XXX-XXXX
        return f"({cleaned[:3]}) {cleaned[3:6]}-{cleaned[6:]}"
    
    @validator('message')
    def validate_message(cls, v):
        if not v.strip():
            raise ValueError('Le message ne peut pas être vide')
        return v.strip()


class ContactMessage(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    nom: str
    email: str
    telephone: Optional[str] = None
    message: str
    ticketNumber: str = Field(default_factory=lambda: f"MSG-{uuid.uuid4().hex[:9].upper()}")
    status: ContactStatus = ContactStatus.nouveau
    createdAt: datetime = Field(default_factory=datetime.utcnow)
    updatedAt: datetime = Field(default_factory=datetime.utcnow)
    
    class Config:
        use_enum_values = True