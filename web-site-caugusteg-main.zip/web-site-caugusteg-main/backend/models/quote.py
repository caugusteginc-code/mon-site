from pydantic import BaseModel, Field, EmailStr, validator
from typing import Optional, List
from datetime import datetime
from enum import Enum
import uuid
import re


class ClientType(str, Enum):
    particulier = "particulier"
    petite_entreprise = "petite-entreprise"
    moyenne_entreprise = "moyenne-entreprise" 
    grande_entreprise = "grande-entreprise"


class Priority(str, Enum):
    low = "low"
    normal = "normal"
    high = "high"
    critical = "critical"


class QuoteStatus(str, Enum):
    nouveau = "nouveau"
    en_cours = "en_cours"
    devis_envoye = "devis_envoye"
    accepte = "accepte"
    refuse = "refuse"


class ServiceType(str, Enum):
    support = "support"
    installation = "installation"
    maintenance = "maintenance"
    cybersecurity = "cybersecurity"
    assistance = "assistance"
    autre = "autre"


class QuoteRequestCreate(BaseModel):
    nom: str = Field(..., min_length=2, max_length=100, description="Nom complet")
    email: EmailStr = Field(..., description="Adresse email valide")
    telephone: str = Field(..., description="Numéro de téléphone obligatoire")
    entreprise: Optional[str] = Field(None, max_length=200, description="Nom de l'entreprise")
    typeClient: ClientType = Field(..., description="Type de client")
    services: List[ServiceType] = Field(..., min_items=1, description="Services demandés")
    description: Optional[str] = Field(None, max_length=2000, description="Description détaillée")
    priorite: Priority = Field(default=Priority.normal, description="Niveau de priorité")
    
    @validator('nom')
    def validate_nom(cls, v):
        if not v.strip():
            raise ValueError('Le nom ne peut pas être vide')
        if not re.search(r'[a-zA-ZÀ-ÿ]', v):
            raise ValueError('Le nom doit contenir des lettres')
        return v.strip()
    
    @validator('telephone')
    def validate_telephone(cls, v):
        if not v:
            raise ValueError('Le numéro de téléphone est obligatoire')
        # Nettoyer le téléphone
        cleaned = re.sub(r'[^\d]', '', v)
        # Vérifier format canadien (10 chiffres)
        if len(cleaned) != 10:
            raise ValueError('Le numéro de téléphone doit contenir 10 chiffres')
        # Formatter au format (XXX) XXX-XXXX
        return f"({cleaned[:3]}) {cleaned[3:6]}-{cleaned[6:]}"
    
    @validator('entreprise')
    def validate_entreprise(cls, v):
        if v is not None:
            return v.strip() if v.strip() else None
        return v
    
    @validator('services')
    def validate_services(cls, v):
        if not v:
            raise ValueError('Au moins un service doit être sélectionné')
        # Vérifier que tous les services sont valides
        valid_services = [service.value for service in ServiceType]
        for service in v:
            if service not in valid_services:
                raise ValueError(f'Service invalide: {service}')
        return v
    
    @validator('description')
    def validate_description(cls, v):
        if v is not None:
            return v.strip() if v.strip() else None
        return v


class QuoteRequest(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    nom: str
    email: str
    telephone: str
    entreprise: Optional[str] = None
    typeClient: ClientType
    services: List[ServiceType]
    description: Optional[str] = None
    priorite: Priority
    referenceNumber: str = Field(default_factory=lambda: f"DEV-{uuid.uuid4().hex[:9].upper()}")
    status: QuoteStatus = QuoteStatus.nouveau
    estimatedValue: Optional[float] = None
    createdAt: datetime = Field(default_factory=datetime.utcnow)
    updatedAt: datetime = Field(default_factory=datetime.utcnow)
    
    class Config:
        use_enum_values = True


class QuoteResponse(BaseModel):
    success: bool
    message: str
    referenceNumber: str
    timestamp: datetime