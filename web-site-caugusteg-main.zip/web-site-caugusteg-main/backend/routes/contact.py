from fastapi import APIRouter, HTTPException, Depends
from motor.motor_asyncio import AsyncIOMotorDatabase
from datetime import datetime
import logging
from typing import Dict, Any

from models.contact import ContactMessageCreate, ContactMessage
from database import get_database

# Configuration du logger
logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api", tags=["Contact"])


@router.post("/contact")
async def submit_contact_form(
    contact_data: ContactMessageCreate,
    db: AsyncIOMotorDatabase = Depends(get_database)
) -> Dict[str, Any]:
    """
    Endpoint pour recevoir les messages de contact du formulaire.
    """
    try:
        # Créer l'objet ContactMessage avec génération automatique des IDs
        contact_message = ContactMessage(
            nom=contact_data.nom,
            email=contact_data.email,
            telephone=contact_data.telephone,
            message=contact_data.message
        )
        
        # Log de la demande (sans données sensibles)
        logger.info(f"Nouvelle demande de contact de {contact_message.nom} ({contact_message.email}) - Ticket: {contact_message.ticketNumber}")
        
        # Sauvegarder en base de données
        contact_dict = contact_message.dict()
        result = await db.contact_messages.insert_one(contact_dict)
        
        if not result.inserted_id:
            logger.error("Échec de l'insertion en base de données")
            raise HTTPException(
                status_code=500,
                detail="Erreur lors de la sauvegarde du message"
            )
        
        # Log de succès
        logger.info(f"Message de contact sauvegardé avec succès - ID: {result.inserted_id}")
        
        # Retourner la réponse de succès
        return {
            "success": True,
            "message": "Votre message a été envoyé avec succès ! Nous vous répondrons rapidement.",
            "ticketNumber": contact_message.ticketNumber,
            "timestamp": contact_message.createdAt.isoformat()
        }
        
    except ValueError as e:
        # Erreurs de validation
        logger.warning(f"Erreur de validation pour contact: {str(e)}")
        raise HTTPException(
            status_code=400,
            detail={
                "success": False,
                "message": "Données invalides",
                "errors": [str(e)]
            }
        )
        
    except Exception as e:
        # Erreurs système
        logger.error(f"Erreur système lors du traitement du contact: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=500,
            detail={
                "success": False,
                "message": "Une erreur technique est survenue. Veuillez réessayer plus tard.",
                "errors": ["Erreur interne du serveur"]
            }
        )


@router.get("/contact/messages")
async def get_contact_messages(
    limit: int = 50,
    skip: int = 0,
    db: AsyncIOMotorDatabase = Depends(get_database)
) -> Dict[str, Any]:
    """
    Endpoint pour récupérer les messages de contact (pour l'admin).
    """
    try:
        # Récupérer les messages avec pagination
        cursor = db.contact_messages.find().sort("createdAt", -1).skip(skip).limit(limit)
        messages = await cursor.to_list(length=limit)
        
        # Compter le total
        total = await db.contact_messages.count_documents({})
        
        # Convertir les ObjectId en string pour la sérialisation
        for message in messages:
            message["_id"] = str(message["_id"])
        
        return {
            "success": True,
            "messages": messages,
            "total": total,
            "limit": limit,
            "skip": skip
        }
        
    except Exception as e:
        logger.error(f"Erreur lors de la récupération des messages: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=500,
            detail={
                "success": False,
                "message": "Erreur lors de la récupération des messages",
                "errors": ["Erreur interne du serveur"]
            }
        )