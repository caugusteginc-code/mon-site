from fastapi import APIRouter, HTTPException, Depends
from motor.motor_asyncio import AsyncIOMotorDatabase
from datetime import datetime
import logging
from typing import Dict, Any

from models.quote import QuoteRequestCreate, QuoteRequest, QuoteResponse
from database import get_database

# Configuration du logger
logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api", tags=["Quote"])


@router.post("/quote")
async def submit_quote_request(
    quote_data: QuoteRequestCreate,
    db: AsyncIOMotorDatabase = Depends(get_database)
) -> Dict[str, Any]:
    """
    Endpoint pour recevoir les demandes de devis du formulaire.
    """
    try:
        # Créer l'objet QuoteRequest avec génération automatique des IDs
        quote_request = QuoteRequest(
            nom=quote_data.nom,
            email=quote_data.email,
            telephone=quote_data.telephone,
            entreprise=quote_data.entreprise,
            typeClient=quote_data.typeClient,
            services=quote_data.services,
            description=quote_data.description,
            priorite=quote_data.priorite
        )
        
        # Log de la demande (sans données sensibles)
        services_str = ", ".join([service.value for service in quote_data.services])
        logger.info(f"Nouvelle demande de devis de {quote_request.nom} ({quote_request.email}) - "
                   f"Ref: {quote_request.referenceNumber} - Services: {services_str} - Priorité: {quote_request.priorite}")
        
        # Sauvegarder en base de données
        quote_dict = quote_request.dict()
        result = await db.quote_requests.insert_one(quote_dict)
        
        if not result.inserted_id:
            logger.error("Échec de l'insertion de la demande de devis en base")
            raise HTTPException(
                status_code=500,
                detail="Erreur lors de la sauvegarde de la demande de devis"
            )
        
        # Log de succès
        logger.info(f"Demande de devis sauvegardée avec succès - ID: {result.inserted_id}")
        
        # Déterminer le message en fonction de la priorité
        if quote_request.priorite == "critical":
            response_message = "Votre demande de devis urgente a été reçue ! Nous vous contacterons dans les 2 heures."
        elif quote_request.priorite == "high":
            response_message = "Votre demande de devis prioritaire a été reçue ! Nous vous contacterons dans les 24h."
        else:
            response_message = "Votre demande de devis a été envoyée avec succès ! Nous vous contacterons dans les 24-48h."
        
        # Retourner la réponse de succès
        return {
            "success": True,
            "message": response_message,
            "referenceNumber": quote_request.referenceNumber,
            "timestamp": quote_request.createdAt.isoformat()
        }
        
    except ValueError as e:
        # Erreurs de validation
        logger.warning(f"Erreur de validation pour devis: {str(e)}")
        raise HTTPException(
            status_code=400,
            detail={
                "success": False,
                "message": "Données invalides",
                "errors": [str(e)]
            }
        )
        
    except Exception as e:
        # Erreurs système
        logger.error(f"Erreur système lors du traitement du devis: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=500,
            detail={
                "success": False,
                "message": "Une erreur technique est survenue. Veuillez réessayer plus tard.",
                "errors": ["Erreur interne du serveur"]
            }
        )


@router.get("/quote/requests")
async def get_quote_requests(
    limit: int = 50,
    skip: int = 0,
    status: str = None,
    db: AsyncIOMotorDatabase = Depends(get_database)
) -> Dict[str, Any]:
    """
    Endpoint pour récupérer les demandes de devis (pour l'admin).
    """
    try:
        # Construire le filtre
        filter_query = {}
        if status:
            filter_query["status"] = status
        
        # Récupérer les demandes avec pagination
        cursor = db.quote_requests.find(filter_query).sort("createdAt", -1).skip(skip).limit(limit)
        requests = await cursor.to_list(length=limit)
        
        # Compter le total
        total = await db.quote_requests.count_documents(filter_query)
        
        # Convertir les ObjectId en string pour la sérialisation
        for request in requests:
            request["_id"] = str(request["_id"])
        
        return {
            "success": True,
            "requests": requests,
            "total": total,
            "limit": limit,
            "skip": skip,
            "filter": filter_query
        }
        
    except Exception as e:
        logger.error(f"Erreur lors de la récupération des devis: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=500,
            detail={
                "success": False,
                "message": "Erreur lors de la récupération des demandes de devis",
                "errors": ["Erreur interne du serveur"]
            }
        )


@router.get("/quote/{reference_number}")
async def get_quote_by_reference(
    reference_number: str,
    db: AsyncIOMotorDatabase = Depends(get_database)
) -> Dict[str, Any]:
    """
    Endpoint pour récupérer une demande de devis par numéro de référence.
    """
    try:
        # Rechercher la demande de devis
        quote_request = await db.quote_requests.find_one({"referenceNumber": reference_number})
        
        if not quote_request:
            raise HTTPException(
                status_code=404,
                detail={
                    "success": False,
                    "message": "Demande de devis introuvable",
                    "errors": [f"Aucune demande trouvée pour la référence {reference_number}"]
                }
            )
        
        # Convertir l'ObjectId en string
        quote_request["_id"] = str(quote_request["_id"])
        
        return {
            "success": True,
            "request": quote_request
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erreur lors de la récupération du devis {reference_number}: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=500,
            detail={
                "success": False,
                "message": "Erreur lors de la récupération de la demande",
                "errors": ["Erreur interne du serveur"]
            }
        )