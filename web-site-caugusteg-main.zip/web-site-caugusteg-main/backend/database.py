from motor.motor_asyncio import AsyncIOMotorClient, AsyncIOMotorDatabase
import os
from typing import Optional

# Variables globales pour la connexion
client: Optional[AsyncIOMotorClient] = None
database: Optional[AsyncIOMotorDatabase] = None


async def connect_to_mongo():
    """Établit la connexion à MongoDB"""
    global client, database
    
    mongo_url = os.environ.get('MONGO_URL')
    if not mongo_url:
        raise ValueError("MONGO_URL environment variable is not set")
    
    db_name = os.environ.get('DB_NAME', 'caugusteg_db')
    
    # Créer la connexion
    client = AsyncIOMotorClient(mongo_url)
    database = client[db_name]
    
    # Tester la connexion
    try:
        await client.admin.command('ping')
        print(f"✅ Connected to MongoDB database: {db_name}")
    except Exception as e:
        print(f"❌ Failed to connect to MongoDB: {e}")
        raise


async def close_mongo_connection():
    """Ferme la connexion à MongoDB"""
    global client
    if client:
        client.close()
        print("✅ MongoDB connection closed")


def get_database() -> AsyncIOMotorDatabase:
    """Dependency pour obtenir la base de données"""
    if database is None:
        raise RuntimeError("Database not initialized. Call connect_to_mongo() first.")
    return database


async def create_indexes():
    """Crée les index pour optimiser les performances"""
    if database is None:
        return
    
    try:
        # Index pour les messages de contact
        await database.contact_messages.create_index("ticketNumber", unique=True)
        await database.contact_messages.create_index("email")
        await database.contact_messages.create_index("createdAt")
        await database.contact_messages.create_index("status")
        
        # Index pour les demandes de devis
        await database.quote_requests.create_index("referenceNumber", unique=True)
        await database.quote_requests.create_index("email")
        await database.quote_requests.create_index("createdAt")
        await database.quote_requests.create_index("status")
        await database.quote_requests.create_index("priorite")
        await database.quote_requests.create_index("typeClient")
        
        print("✅ Database indexes created successfully")
        
    except Exception as e:
        print(f"⚠️ Warning: Could not create indexes: {e}")
        # Ne pas faire échouer l'application si les index ne peuvent pas être créés